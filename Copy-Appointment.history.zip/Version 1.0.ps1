#requires -Version 2
function Copy-Appointment 
{  
    [cmdletbinding()]
    param(

        [Parameter(ValueFromPipelineByPropertyName = $True )]
        [Parameter(ParameterSetName = 'Pattern')]
    
        $Pattern
        ,

        [Parameter(ParameterSetName = 'Subject')]
        $Subject 
        ,

        [datetime]
        $Start = (Get-Date).addminutes(-30)
        ,

        [switch]
        $ShowAppointment = $False

    )

    [array]$MatchedAppt = $TimeBudgetCache | Where-Object -FilterScript { $_.Subject -match $Pattern } 
    
    $ChosenSubjects = @()
    
    if ($MatchedAppt.Count -gt 1 ) 
    { 
        $MatchedAppt |
        Select-Object -Property @{ Name  = 'Index'; Expression = { [array]::IndexOf($MatchedAppt, $_)  } }, Subject, Duration, Categories | Format-Table  -AutoSize
   
        [string]$SelectedIndexNumbers = Read-Host -Prompt 'Please Choose the Index Number of your Selected Appointment'
        
        [int32[]]$SelectedSubjects = $SelectedIndexNumbers -split { $_ -eq ' ' -or $_ -eq ',' } | Where-Object -FilterScript { $_ } | ForEach-Object -Process { $_.trim() } 

        foreach ( $Selection in $SelectedSubjects )
        { 
            $ChosenSubjects += $MatchedAppt[$Selection] 
        }
    } 
    else 
    {
        [int32[]]$Selection = 0
        $ChosenSubjects = $MatchedAppt[$Selection]
    }

    foreach ( $Choice in $ChosenSubjects ) 
    {

        $Properties = @{}
        $Properties.Start = $Start
        $Properties.Subject =  $Choice.Subject 
        $Properties.Minutes = $Choice.Duration
        $Properties.Categories = @($Choice.Categories) 
        $Properties.Location = $Choice.Location
        $Properties.Body = $Choice.Body
        $Properties.ReminderMinutes = $Choice.ReminderSet
        $Properties.ShowAppointment = $False

       New-Appointment @Properties

    }
}
